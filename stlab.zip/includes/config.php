<?php
session_start();
date_default_timezone_set("America/Santiago");
<<<<<<< HEAD
$URLBASE = "http://stlab.online";
=======
$URLBASE = "http://localhost:8003";
>>>>>>> 7a2bf56bc4a09c491bdb3380897143ba50a5867e
?>