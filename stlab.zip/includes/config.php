<?php
session_start();
date_default_timezone_set("America/Santiago");
$URLBASE = "http://stlab.online";
?>